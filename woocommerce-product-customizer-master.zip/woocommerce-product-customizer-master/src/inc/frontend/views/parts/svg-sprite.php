<?php if (!defined('ABSPATH')) exit; ?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" style="display: none;">
	<defs>
		<g id="mkl-pc-icons--plus"><rect x="60" y="240" width="392" height="30"/><rect x="60" y="240" width="392" height="30" transform="translate(0 512) rotate(-90)"/></g>
		<g id="mkl-pc-icons--minus"><rect x="60" y="240" width="392" height="30"/></g>
	</defs>
</svg>
